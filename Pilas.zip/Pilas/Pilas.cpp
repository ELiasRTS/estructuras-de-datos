#include<iostream>
#include "Pila.h"
using namespace std;
int main(){
	int elem;
	Pila pilita;
	cout << "Ingresa el valor de la pila:"; cin >> elem;
	if (pilita.push(elem)) {
		cout << "Valor ingresado\n";
	}
}


